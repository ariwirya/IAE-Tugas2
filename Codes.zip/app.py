from flask import Flask, request, jsonify
from flask_cors import CORS
from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

app = Flask(__name__)
CORS(app)

# Konfigurasi database
engine = create_engine('sqlite:///inventory.db')
Base = declarative_base()
Session = sessionmaker(bind=engine)

# Model Barang
class Barang(Base):
    __tablename__ = 'barang'
    id = Column(Integer, primary_key=True)
    nama = Column(String(100), nullable=False)
    jumlah = Column(Integer, nullable=False)
    harga = Column(Float, nullable=False)

# Buat tabel
Base.metadata.create_all(engine)

# Routes
@app.route('/barang', methods=['GET'])
def get_barang():
    session = Session()
    barang = session.query(Barang).all()
    result = [{
        'id': b.id,
        'nama': b.nama,
        'jumlah': b.jumlah,
        'harga': b.harga
    } for b in barang]
    session.close()
    return jsonify(result)

@app.route('/barang/<int:barang_id>', methods=['GET'])
def get_barang_by_id(barang_id):
    session = Session()
    barang = session.query(Barang).filter_by(id=barang_id).first()
    if barang:
        result = {
            'id': barang.id,
            'nama': barang.nama,
            'jumlah': barang.jumlah,
            'harga': barang.harga
        }
        session.close()
        return jsonify(result)
    session.close()
    return jsonify({'error': 'Barang tidak ditemukan'}), 404

@app.route('/barang', methods=['POST'])
def create_barang():
    data = request.json
    session = Session()
    new_barang = Barang(
        nama=data['nama'],
        jumlah=data['jumlah'],
        harga=data['harga']
    )
    session.add(new_barang)
    session.commit()
    result = {
        'id': new_barang.id,
        'nama': new_barang.nama,
        'jumlah': new_barang.jumlah,
        'harga': new_barang.harga
    }
    session.close()
    return jsonify(result), 201

@app.route('/barang/<int:barang_id>', methods=['PUT'])
def update_barang(barang_id):
    data = request.json
    session = Session()
    barang = session.query(Barang).filter_by(id=barang_id).first()
    if barang:
        barang.nama = data.get('nama', barang.nama)
        barang.jumlah = data.get('jumlah', barang.jumlah)
        barang.harga = data.get('harga', barang.harga)
        session.commit()
        result = {
            'id': barang.id,
            'nama': barang.nama,
            'jumlah': barang.jumlah,
            'harga': barang.harga
        }
        session.close()
        return jsonify(result)
    session.close()
    return jsonify({'error': 'Barang tidak ditemukan'}), 404

@app.route('/barang/<int:barang_id>', methods=['DELETE'])
def delete_barang(barang_id):
    session = Session()
    barang = session.query(Barang).filter_by(id=barang_id).first()
    if barang:
        session.delete(barang)
        session.commit()
        session.close()
        return jsonify({'message': 'Barang berhasil dihapus'})
    session.close()
    return jsonify({'error': 'Barang tidak ditemukan'}), 404

if __name__ == '__main__':
    app.run(debug=True)
