const API_URL = "http://localhost:5000/barang";

// DOM Elements
const barangForm = document.getElementById("barangForm");
const barangList = document.getElementById("barangList");
const namaInput = document.getElementById("nama");
const jumlahInput = document.getElementById("jumlah");
const hargaInput = document.getElementById("harga");

// Modal Elements
const editModal = document.getElementById("editModal");
const deleteModal = document.getElementById("deleteModal");
const editBarangForm = document.getElementById("editBarangForm");
const editNamaInput = document.getElementById("editNama");
const editJumlahInput = document.getElementById("editJumlah");
const editHargaInput = document.getElementById("editHarga");
const closeModal = document.querySelector(".close");
const confirmDeleteBtn = document.getElementById("confirmDelete");
const cancelDeleteBtn = document.getElementById("cancelDelete");

// State
let editingBarangId = null;
let deletingBarangId = null;

// Event Listeners
barangForm.addEventListener("submit", handleSubmit);
editBarangForm.addEventListener("submit", handleEditSubmit);
closeModal.addEventListener("click", closeEditModal);
confirmDeleteBtn.addEventListener("click", confirmDelete);
cancelDeleteBtn.addEventListener("click", closeDeleteModal);

// Close modal when clicking outside
window.addEventListener("click", (event) => {
  if (event.target === editModal) {
    closeEditModal();
  }
  if (event.target === deleteModal) {
    closeDeleteModal();
  }
});

function closeEditModal() {
  editModal.style.display = "none";
  editingBarangId = null;
}

function closeDeleteModal() {
  deleteModal.style.display = "none";
  deletingBarangId = null;
}

// Functions
async function fetchBarang() {
  try {
    const response = await fetch(API_URL);
    const barang = await response.json();
    displayBarang(barang);
  } catch (error) {
    console.error("Error fetching barang:", error);
    showError("Gagal memuat data barang");
  }
}

function displayBarang(barang) {
  barangList.innerHTML = "";
  barang.forEach((b) => {
    const barangElement = document.createElement("div");
    barangElement.className = "barang";
    barangElement.innerHTML = `
            <h3>${b.nama}</h3>
            <p><strong>Stok:</strong> ${b.jumlah} unit</p>
            <p><strong>Harga:</strong> Rp ${b.harga.toLocaleString()}</p>
            <div class="actions">
                <button class="edit-btn" onclick="editBarang(${
                  b.id
                })">Edit</button>
                <button class="delete-btn" onclick="deleteBarang(${
                  b.id
                })">Hapus</button>
            </div>
        `;
    barangList.appendChild(barangElement);
  });
}

async function handleSubmit(e) {
  e.preventDefault();
  const submitButton = barangForm.querySelector('button[type="submit"]');
  const originalText = submitButton.textContent;

  try {
    submitButton.textContent = editingBarangId
      ? "Menyimpan..."
      : "Menambahkan...";
    submitButton.disabled = true;

    const barangData = {
      nama: namaInput.value,
      jumlah: parseInt(jumlahInput.value),
      harga: parseFloat(hargaInput.value),
    };

    if (editingBarangId) {
      await updateBarang(editingBarangId, barangData);
      showSuccess("Barang berhasil diperbarui");
      editingBarangId = null;
      submitButton.textContent = "Tambah Barang";
    } else {
      await createBarang(barangData);
      showSuccess("Barang berhasil ditambahkan");
    }

    barangForm.reset();
    fetchBarang();
  } catch (error) {
    console.error("Error saving barang:", error);
    showError("Gagal menyimpan data barang");
  } finally {
    submitButton.disabled = false;
  }
}

async function createBarang(barangData) {
  const response = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(barangData),
  });
  if (!response.ok) throw new Error("Gagal menambahkan barang");
  return response.json();
}

async function updateBarang(id, barangData) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(barangData),
  });
  if (!response.ok) throw new Error("Gagal memperbarui barang");
  return response.json();
}

async function deleteBarang(id) {
  deletingBarangId = id;
  deleteModal.style.display = "block";
}

async function confirmDelete() {
  if (!deletingBarangId) return;

  try {
    const response = await fetch(`${API_URL}/${deletingBarangId}`, {
      method: "DELETE",
    });
    if (!response.ok) throw new Error("Gagal menghapus barang");
    showSuccess("Barang berhasil dihapus");
    closeDeleteModal();
    fetchBarang();
  } catch (error) {
    console.error("Error deleting barang:", error);
    showError("Gagal menghapus barang");
  }
}

async function editBarang(id) {
  try {
    const response = await fetch(`${API_URL}/${id}`);
    if (!response.ok) throw new Error("Gagal mengambil data barang");

    const barang = await response.json();

    // Isi form edit dengan data barang
    editNamaInput.value = barang.nama;
    editJumlahInput.value = barang.jumlah;
    editHargaInput.value = barang.harga;

    // Set state editing
    editingBarangId = id;

    // Tampilkan modal
    editModal.style.display = "block";
  } catch (error) {
    console.error("Error fetching barang for edit:", error);
    showError("Gagal memuat data barang untuk diedit");
  }
}

async function handleEditSubmit(e) {
  e.preventDefault();
  const submitButton = editBarangForm.querySelector('button[type="submit"]');

  try {
    submitButton.textContent = "Menyimpan...";
    submitButton.disabled = true;

    const barangData = {
      nama: editNamaInput.value,
      jumlah: parseInt(editJumlahInput.value),
      harga: parseFloat(editHargaInput.value),
    };

    await updateBarang(editingBarangId, barangData);
    showSuccess("Barang berhasil diperbarui");
    closeEditModal();
    fetchBarang();
  } catch (error) {
    console.error("Error updating barang:", error);
    showError("Gagal memperbarui data barang");
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Simpan Perubahan";
  }
}

function showError(message) {
  const errorDiv = document.createElement("div");
  errorDiv.className = "error";
  errorDiv.textContent = message;
  barangForm.insertAdjacentElement("beforebegin", errorDiv);
  setTimeout(() => errorDiv.remove(), 3000);
}

function showSuccess(message) {
  const successDiv = document.createElement("div");
  successDiv.className = "success";
  successDiv.textContent = message;
  barangForm.insertAdjacentElement("beforebegin", successDiv);
  setTimeout(() => successDiv.remove(), 3000);
}

// Initial fetch
fetchBarang();
